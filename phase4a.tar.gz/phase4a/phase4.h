/*
 * These are the definitions for phase 4 of the project (support level, part 2).
 */

#ifndef _PHASE4_H
#define _PHASE4_H

#define MAXLINE         80

extern void phase4_init(void);

#endif /* _PHASE4_H */
